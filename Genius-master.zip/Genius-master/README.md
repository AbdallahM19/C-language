# TEST SUITE FOR SIMPLE SHELL PROJECT

## How to use:

### Do the following and then hit Enter.
**Everything has been conigured, just clone into your *simple_shell* project directory**
* 1. clone the repository: **https://github.com/Genius-Excel/Genius.git**
* 2. move the "TEST_SUITE" directory inside your project: **mv Genius/TEST_SUITE/ .**
* 3. move the bash script inside your project: **mv Genius/runchecker.bash .**
* 4. run checker test on a specific task: **./runchecker.bash #**
* 5. run checker test on all tasks: **./runchecker.bash**
## Goodluck in your shell project, if you find this helpful follow this account.
