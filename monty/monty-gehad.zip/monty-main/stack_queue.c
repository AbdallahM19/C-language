#include "monty.h"
/**
*f_stack - add as a stack
*@num: unsinged int
*@first: pointer of pointer to the stack
*/
void f_stack(stack_t **first, unsigned int num)
{
(void) num, (void) first;
args.lilo = 0;
}
/**
*f_queue - add as a queue
*@num: unsinged int
*@first: pointer of pointer to the stack
*/
void f_queue(stack_t **first, unsigned int num)
{
(void) num, (void) first;
args.lilo = 1;
}
