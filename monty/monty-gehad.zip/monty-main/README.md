# monty
C - Stacks, Queues - LIFO, FIFO
