#include "monty.h"
/**
*f_nop - do not do any thing
*@first: pointer of pointer to the stack
*
*@num: void int
*/
void f_nop(stack_t **first, unsigned int num)
{
	(void) first;
	(void) num;
}
