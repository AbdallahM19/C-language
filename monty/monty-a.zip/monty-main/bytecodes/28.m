push 72
pchar
