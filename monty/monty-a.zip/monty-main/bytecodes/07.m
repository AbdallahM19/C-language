push 1
push 2
push 3
pall
pop
pall
pop
pall
pop
pall
